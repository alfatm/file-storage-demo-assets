const env = process.env;

export const config = {
  port: Number(env.PORT ?? 5212),
  backend: (env.FILEX_BACKEND ?? "local") as "local" | "s3" | "webdav",
  localRoot: env.FILEX_ROOT ?? "./demo",
  maxUploadBytes: Number(env.FILEX_MAX_UPLOAD ?? 5 * 1024 ** 3),
  sessionCookie: "filex_session",
  tokenTtlDays: Number(env.FILEX_TOKEN_TTL_DAYS ?? 90),
  s3: {
    bucket: env.FILEX_S3_BUCKET ?? "filex-demo",
    region: env.FILEX_S3_REGION ?? "eu-central-1",
    endpoint: env.FILEX_S3_ENDPOINT,
  },
  webdav: {
    url: env.FILEX_WEBDAV_URL ?? "https://nas.internal/dav",
    auth: env.FILEX_WEBDAV_AUTH ?? "",
  },
  thumbnails: {
    sizes: [128, 256, 512],
    quality: 82,
  },
} as const;

export type Config = typeof config;
