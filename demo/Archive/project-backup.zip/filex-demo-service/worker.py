"""Background worker: extracts text from uploaded documents for content search."""

import json
import logging
import sys
import time
import zipfile
from pathlib import Path
from xml.etree import ElementTree

log = logging.getLogger("worker")
QUEUE = Path("./queue")
INDEX = Path("./index")
WORD_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def extract_docx(path: Path) -> str:
    with zipfile.ZipFile(path) as z:
        root = ElementTree.fromstring(z.read("word/document.xml"))
    return " ".join(t.text or "" for t in root.iter(WORD_NS + "t"))


def extract_text(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".docx":
        return extract_docx(path)
    if suffix in {".md", ".txt", ".csv", ".json", ".yaml", ".yml", ".html"}:
        return path.read_text(encoding="utf-8", errors="replace")
    log.info("no extractor for %s", suffix)
    return ""


def process(job: Path) -> None:
    payload = json.loads(job.read_text())
    source = Path(payload["path"])
    text = extract_text(source)
    out = INDEX / (source.name + ".txt")
    out.write_text(text[:200_000], encoding="utf-8")
    job.unlink()
    log.info("indexed %s (%d chars)", source, len(text))


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    QUEUE.mkdir(exist_ok=True)
    INDEX.mkdir(exist_ok=True)
    while True:
        jobs = sorted(QUEUE.glob("*.json"))
        if not jobs:
            time.sleep(1)
            continue
        for job in jobs:
            try:
                process(job)
            except Exception:
                log.exception("job %s failed", job.name)
                job.rename(job.with_suffix(".failed"))


if __name__ == "__main__":
    sys.exit(main())
