import { Router } from "express";
import { authenticate } from "./auth";
import { config } from "./config";
import { searchIndex } from "./search";
import { storage } from "./storage";

export const api = Router();

api.use(authenticate);

api.get("/files", async (req, res) => {
  const path = String(req.query.path ?? "/");
  const entries = await storage.list(path);
  res.json({ entries });
});

api.post("/folders", async (req, res) => {
  const entry = await storage.mkdir(String(req.body.path));
  res.status(201).json(entry);
});

api.post("/upload", async (req, res) => {
  const { path, overwrite } = req.body;
  if (req.file.size > config.maxUploadBytes) {
    return res.status(413).json({ error: "file too large", path });
  }
  const entry = await storage.write(path, req.file.stream, { overwrite: overwrite === "true" });
  await searchIndex.enqueue(entry);
  res.status(201).json(entry);
});

api.get("/download", async (req, res) => {
  const path = String(req.query.path);
  const { stream, size, mime } = await storage.read(path);
  res.setHeader("Content-Length", size);
  res.setHeader("Content-Type", mime);
  stream.pipe(res);
});

api.get("/search", async (req, res) => {
  const results = await searchIndex.query(String(req.query.q), {
    path: req.query.path ? String(req.query.path) : undefined,
    content: req.query.content === "1",
    limit: Number(req.query.limit ?? 50),
  });
  res.json({ results });
});

api.delete("/files", async (req, res) => {
  await storage.remove(String(req.query.path));
  res.status(204).end();
});
