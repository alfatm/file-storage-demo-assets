import { Entry } from "./storage";

export interface QueryOptions {
  path?: string;
  content?: boolean;
  limit: number;
}

interface IndexedDoc {
  entry: Entry;
  tokens: Set<string>;
  text?: string;
}

const TOKEN = /[\p{L}\p{N}]{2,}/gu;

export function tokenize(text: string): Set<string> {
  return new Set((text.toLowerCase().match(TOKEN) ?? []));
}

/** In-memory inverted index. The production build swaps this for the SQLite FTS5 index. */
class SearchIndex {
  private readonly docs = new Map<string, IndexedDoc>();
  private readonly queue: Entry[] = [];

  async enqueue(entry: Entry): Promise<void> {
    this.queue.push(entry);
    if (this.queue.length === 1) setImmediate(() => this.drain());
  }

  async query(q: string, opts: QueryOptions): Promise<Entry[]> {
    const terms = [...tokenize(q)];
    const hits: Array<{ entry: Entry; score: number }> = [];
    for (const doc of this.docs.values()) {
      if (opts.path && !doc.entry.path.startsWith(opts.path)) continue;
      let score = 0;
      for (const t of terms) {
        if (doc.entry.name.toLowerCase().includes(t)) score += 3;
        if (doc.tokens.has(t)) score += 1;
        if (opts.content && doc.text?.includes(t)) score += 2;
      }
      if (score > 0) hits.push({ entry: doc.entry, score });
    }
    return hits.sort((a, b) => b.score - a.score).slice(0, opts.limit).map((h) => h.entry);
  }

  private async drain(): Promise<void> {
    while (this.queue.length) {
      const entry = this.queue.shift()!;
      const text = await extractText(entry);
      this.docs.set(entry.path, { entry, tokens: tokenize(entry.name + " " + (text ?? "")), text: text?.toLowerCase() });
    }
  }
}

async function extractText(entry: Entry): Promise<string | undefined> {
  if (entry.isDir) return undefined;
  if (/\.(md|txt|csv|json|ya?ml|html?|ts|py|go)$/i.test(entry.name)) return undefined; // read directly by worker
  return undefined; // PDF / DOCX extraction is handled by worker.py
}

export const searchIndex = new SearchIndex();
