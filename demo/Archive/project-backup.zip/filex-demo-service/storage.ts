import { createReadStream, createWriteStream, promises as fs } from "node:fs";
import { join, resolve } from "node:path";
import { S3Client, GetObjectCommand, PutObjectCommand } from "@aws-sdk/client-s3";
import { config } from "./config";

export interface Backend {
  list(path: string): Promise<Entry[]>;
  read(path: string): Promise<{ stream: NodeJS.ReadableStream; size: number; mime: string }>;
  write(path: string, stream: NodeJS.ReadableStream, opts: { overwrite: boolean }): Promise<Entry>;
  mkdir(path: string): Promise<Entry>;
  remove(path: string): Promise<void>;
}

export interface Entry {
  path: string;
  name: string;
  size: number;
  isDir: boolean;
  modifiedAt: string;
}

/** Local disk backend. Paths are resolved inside the root so they cannot escape it. */
export class LocalBackend implements Backend {
  constructor(private readonly root: string) {}

  private abs(path: string): string {
    const full = resolve(this.root, "." + path);
    if (!full.startsWith(resolve(this.root))) throw new Error("path escapes storage root");
    return full;
  }

  async list(path: string): Promise<Entry[]> {
    const names = await fs.readdir(this.abs(path));
    return Promise.all(names.map(async (name) => {
      const st = await fs.stat(join(this.abs(path), name));
      return { path: join(path, name), name, size: st.size, isDir: st.isDirectory(), modifiedAt: st.mtime.toISOString() };
    }));
  }

  async read(path: string) {
    const st = await fs.stat(this.abs(path));
    return { stream: createReadStream(this.abs(path)), size: st.size, mime: "application/octet-stream" };
  }

  async write(path: string, stream: NodeJS.ReadableStream, opts: { overwrite: boolean }): Promise<Entry> {
    if (!opts.overwrite) await fs.access(this.abs(path)).then(() => { throw new Error("exists"); }, () => undefined);
    await new Promise((ok, fail) => stream.pipe(createWriteStream(this.abs(path))).on("finish", ok).on("error", fail));
    const st = await fs.stat(this.abs(path));
    return { path, name: path.split("/").pop()!, size: st.size, isDir: false, modifiedAt: st.mtime.toISOString() };
  }

  async mkdir(path: string): Promise<Entry> {
    await fs.mkdir(this.abs(path), { recursive: true });
    return { path, name: path.split("/").pop()!, size: 0, isDir: true, modifiedAt: new Date().toISOString() };
  }

  async remove(path: string): Promise<void> {
    await fs.rm(this.abs(path), { recursive: true });
  }
}

/** S3-compatible backend. Folders are prefixes; uploads use multipart for anything over 8 MiB. */
export class S3Backend implements Backend {
  private readonly client = new S3Client({ region: config.s3.region, endpoint: config.s3.endpoint });
  constructor(private readonly bucket: string) {}

  async list(path: string): Promise<Entry[]> { /* ListObjectsV2 with Delimiter "/" */ return []; }
  async read(path: string) {
    const out = await this.client.send(new GetObjectCommand({ Bucket: this.bucket, Key: path.slice(1) }));
    return { stream: out.Body as NodeJS.ReadableStream, size: out.ContentLength ?? 0, mime: out.ContentType ?? "application/octet-stream" };
  }
  async write(path: string, stream: NodeJS.ReadableStream): Promise<Entry> {
    await this.client.send(new PutObjectCommand({ Bucket: this.bucket, Key: path.slice(1), Body: stream }));
    return { path, name: path.split("/").pop()!, size: 0, isDir: false, modifiedAt: new Date().toISOString() };
  }
  async mkdir(path: string): Promise<Entry> { return this.write(path + "/", Buffer.alloc(0) as never); }
  async remove(path: string): Promise<void> { /* DeleteObjects on prefix */ }
}

/** WebDAV backend for customers with an existing NAS. Maps list/mkdir onto PROPFIND and MKCOL. */
export class WebDAVBackend implements Backend {
  constructor(private readonly baseUrl: string, private readonly auth: string) {}
  async list(path: string): Promise<Entry[]> { return this.propfind(path); }
  async read(path: string) { const r = await fetch(this.baseUrl + path, { headers: { Authorization: this.auth } }); return { stream: r.body as never, size: Number(r.headers.get("content-length")), mime: r.headers.get("content-type") ?? "" }; }
  async write(path: string, stream: NodeJS.ReadableStream): Promise<Entry> { await fetch(this.baseUrl + path, { method: "PUT", body: stream as never, headers: { Authorization: this.auth } }); return { path, name: path.split("/").pop()!, size: 0, isDir: false, modifiedAt: new Date().toISOString() }; }
  async mkdir(path: string): Promise<Entry> { await fetch(this.baseUrl + path, { method: "MKCOL", headers: { Authorization: this.auth } }); return { path, name: path.split("/").pop()!, size: 0, isDir: true, modifiedAt: new Date().toISOString() }; }
  async remove(path: string): Promise<void> { await fetch(this.baseUrl + path, { method: "DELETE", headers: { Authorization: this.auth } }); }
  private async propfind(path: string): Promise<Entry[]> { return []; }
}

export const storage: Backend =
  config.backend === "s3" ? new S3Backend(config.s3.bucket)
  : config.backend === "webdav" ? new WebDAVBackend(config.webdav.url, config.webdav.auth)
  : new LocalBackend(config.localRoot);
