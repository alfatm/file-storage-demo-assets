import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import type { NextFunction, Request, Response } from "express";
import { config } from "./config";

export interface Principal {
  userId: string;
  scope: string;
  kind: "session" | "token";
}

interface StoredToken {
  hash: string;
  userId: string;
  scope: string;
  expiresAt?: number;
}

const tokens = new Map<string, StoredToken>();

/** Create a long-lived API token. The plain value is returned once and only its hash is stored. */
export function issueApiToken(userId: string, scope = "/", ttlDays = config.tokenTtlDays): string {
  const plain = "fx_" + randomBytes(24).toString("base64url");
  const id = plain.slice(3, 11);
  tokens.set(id, { hash: sha256(plain), userId, scope, expiresAt: ttlDays ? Date.now() + ttlDays * 86_400_000 : undefined });
  return plain;
}

export function revokeApiToken(plain: string): boolean {
  return tokens.delete(plain.slice(3, 11));
}

function verifyApiToken(plain: string): Principal | undefined {
  const stored = tokens.get(plain.slice(3, 11));
  if (!stored) return undefined;
  if (stored.expiresAt && stored.expiresAt < Date.now()) return undefined;
  const a = Buffer.from(sha256(plain));
  const b = Buffer.from(stored.hash);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return undefined;
  return { userId: stored.userId, scope: stored.scope, kind: "token" };
}

/** Express middleware: accepts a session cookie or a bearer API token. */
export function authenticate(req: Request, res: Response, next: NextFunction): void {
  const header = req.headers.authorization ?? "";
  if (header.startsWith("Bearer ")) {
    const principal = verifyApiToken(header.slice(7));
    if (!principal) {
      res.status(401).json({ error: "invalid or expired API token" });
      return;
    }
    (req as Request & { principal: Principal }).principal = principal;
    return next();
  }
  const session = req.cookies?.[config.sessionCookie];
  if (!session) {
    res.status(401).json({ error: "authentication required" });
    return;
  }
  (req as Request & { principal: Principal }).principal = { userId: session, scope: "/", kind: "session" };
  next();
}

function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}
