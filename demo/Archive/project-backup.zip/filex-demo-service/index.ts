import express from "express";
import cookieParser from "cookie-parser";
import { api } from "./api";
import { config } from "./config";

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use("/api", api);
app.use(express.static("public"));

app.get("/healthz", (_req, res) => res.json({ ok: true, backend: config.backend }));

app.listen(config.port, () => {
  console.log(`filex listening on :${config.port} (backend=${config.backend})`);
});
