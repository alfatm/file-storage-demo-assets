# filex-demo-service

A deliberately small file storage service that backs the Filex demo workspace.
It is not the real Filex backend; it exists so the `Code/` folder has something
coherent to browse and preview.

## Layout

- `index.ts` — Express entry point
- `api.ts` — HTTP routes: list, upload, download, search, delete
- `storage.ts` — storage architecture: local disk, S3 and WebDAV backends behind one interface
- `search.ts` — in-memory inverted index used for name and content search
- `auth.ts` — session cookies and scoped API tokens
- `config.ts` — configuration from environment variables
- `worker.py` — text extraction worker for DOCX and plain-text documents
- `thumbnail.go` — image thumbnail renderer
- `styles.css` — design tokens and the file grid

## Running

```bash
npm install
npm run dev
```

Set `FILEX_BACKEND=s3` with `FILEX_S3_BUCKET` and `FILEX_S3_REGION` to use
object storage, or `FILEX_BACKEND=webdav` with `FILEX_WEBDAV_URL` for a NAS.
